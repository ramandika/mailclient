package com.fsck.k9.activity;

import android.app.Activity;
import android.os.Bundle;

import com.fsck.k9.R;

/**
 * Created by ramandika on 4/24/2016.
 */
public class ChooseKeyECC extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_content_simple);

    }
}
